    </main>
    <footer>

        <a href="" class="btn uppercase">configuration personnalisée</a>
        <a href="" class="btn uppercase">en savoir plus</a>

    </footer>
    <script src="assets/js/index.js"></script>
    <?php wp_footer(); ?>
  </body>
</html>
