<?php get_header(); ?>
<h1>Oups ! 404 !</h1>
<img src="https://image.freepik.com/free-vector/404-error-background-with-boat-flat-style_23-2147761278.jpg" alt="">
<?php get_footer(); ?>