<?php
get_header(); // header.php

get_footer();

?>
