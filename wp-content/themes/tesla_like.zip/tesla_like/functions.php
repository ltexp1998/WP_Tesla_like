<?php
require get_theme_file_path( 'inc/setup.php' );
require get_theme_file_path( 'inc/menus.php' );
require get_theme_file_path( 'inc/scripts.php' );
require get_theme_file_path( 'inc/customizer.php' );
require get_theme_file_path( 'inc/template-tags.php' );
